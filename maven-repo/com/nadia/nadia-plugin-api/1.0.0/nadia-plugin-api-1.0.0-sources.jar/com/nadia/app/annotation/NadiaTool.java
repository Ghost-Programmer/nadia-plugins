package com.nadia.app.annotation;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.core.annotation.AliasFor;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation marking a method as an executable tool for Nadia, Spring AI, PF4J plugins, and AGY cognitive agents.
 * <p>
 * Extends the Spring AI {@link Tool} annotation to provide direct native compatibility
 * with Spring AI function calling, Model Context Protocol (MCP), PF4J {@code NadiaToolExtension} plugins,
 * and AGY JSON Schema discovery.
 * </p>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Tool
public @interface NadiaTool {

    /**
     * The unique name of the tool as exposed in model tool catalogs.
     * If blank, defaults to the annotated method's name.
     *
     * @return the unique tool name
     */
    @AliasFor(annotation = Tool.class, attribute = "name")
    String name() default "";

    /**
     * A human and LLM-readable description of what the tool does, its capabilities, and usage expectations.
     *
     * @return the tool description
     */
    @AliasFor(annotation = Tool.class, attribute = "description")
    String description() default "";

    /**
     * Whether the tool execution result should be returned directly to the client.
     *
     * @return true if return direct, false otherwise
     */
    @AliasFor(annotation = Tool.class, attribute = "returnDirect")
    boolean returnDirect() default false;

    /**
     * Configuration property keys (under {@code nadia.prop.*}) required or used by this tool
     * (e.g., {@code {"nadia.prop.n2yo.apiKey"}} or {@code {"n2yo.apiKey"}}).
     *
     * <p>When discovered by {@code ToolRegistry}, these properties are automatically registered
     * with {@code NadiaPropertiesService} so the Settings UI knows to display them.</p>
     *
     * @return array of property keys needed by the tool
     */
    String[] properties() default {};
}

