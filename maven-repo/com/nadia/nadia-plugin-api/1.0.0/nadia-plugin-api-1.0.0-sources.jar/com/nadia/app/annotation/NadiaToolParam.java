package com.nadia.app.annotation;

import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.core.annotation.AliasFor;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation specifying parameter metadata for a method annotated with {@link NadiaTool} or {@link ToolParam}.
 * <p>
 * Extends Spring AI {@link ToolParam} annotation.
 * </p>
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@ToolParam
public @interface NadiaToolParam {

    /**
     * A description of the parameter for LLM tool call schemas.
     *
     * @return description string
     */
    @AliasFor(annotation = ToolParam.class, attribute = "description")
    String description() default "";

    /**
     * Whether the parameter is strictly required in tool invocation payloads.
     *
     * @return true if required, false if optional
     */
    @AliasFor(annotation = ToolParam.class, attribute = "required")
    boolean required() default true;
}

