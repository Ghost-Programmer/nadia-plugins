package com.nadia.app.orchestrator;

import java.util.Collections;
import java.util.List;

/**
 * Agent tool interface specifying name, description, JSON schema,
 * and execution callback for dynamic tool registration in Nadia and PF4J plugins.
 */
public interface AgentTool {

    /**
     * Returns the unique name of the tool as exposed in LLM prompts.
     *
     * @return the unique tool name
     */
    String getName();

    /**
     * Returns a clear description of the tool's behavior and intent.
     *
     * @return the human/LLM-readable tool description
     */
    String getDescription();

    /**
     * Returns the JSON Schema representation of the tool's expected input arguments.
     *
     * @return JSON Schema string
     */
    String getArgumentSchema();

    /**
     * Returns the list of normalized {@code nadia.prop.*} property keys required or used by this tool.
     *
     * @return list of normalized {@code nadia.prop.*} keys (empty by default)
     */
    default List<String> getRequiredProperties() {
        return Collections.emptyList();
    }

    /**
     * Executes the tool with the supplied JSON argument string.
     *
     * @param jsonArguments the JSON string representing input arguments
     * @return the execution result as a string (often JSON or formatted text)
     */
    String execute(String jsonArguments);
}

