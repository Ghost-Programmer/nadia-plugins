package com.nadia.app.plugin.api;

/**
 * Descriptor for a procedural skill ({@code SKILL.md}) contributed programmatically by a PF4J plugin.
 *
 * @param category        skill category folder under {@code ~/.nadia/skills/} (e.g., {@code "system"}, {@code "geo"})
 * @param skillSlug       kebab-case skill directory name (e.g., {@code "weather-radar"})
 * @param skillMarkdown   full {@code SKILL.md} content including YAML frontmatter and procedural instructions
 */
public record BundledSkillDescriptor(
        String category,
        String skillSlug,
        String skillMarkdown
) {
}

