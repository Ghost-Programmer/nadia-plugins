package com.nadia.app.plugin.api;

/**
 * Descriptor for a specialist staff persona ({@code STAFF.md} and optional {@code cron.json})
 * contributed programmatically by a PF4J plugin.
 *
 * @param staffName     display name of the staff specialist (e.g., {@code "Security Auditor"})
 * @param staffMarkdown full {@code STAFF.md} content including YAML frontmatter and operational directives
 * @param cronJson      optional {@code cron.json} array string for recurring scheduled jobs (may be {@code null})
 */
public record BundledStaffDescriptor(
        String staffName,
        String staffMarkdown,
        String cronJson
) {
}

