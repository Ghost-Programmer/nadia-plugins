package com.nadia.app.plugin.api;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Immutable descriptor representing a localized UI and AI language pack contributed by a PF4J
 * {@link NadiaLanguageExtension} plugin (or Nadia's built-in {@code en-US} fallback bundle).
 *
 * @param localeCode   BCP-47 language/locale tag (e.g., {@code "en-US"}, {@code "en-GB"}, {@code "es"}, {@code "de"}, {@code "fr"})
 * @param displayName  English/international display name (e.g., {@code "English (US)"}, {@code "English (UK)"}, {@code "Spanish"})
 * @param nativeName   endonym / native language name (e.g., {@code "English (US)"}, {@code "English (UK)"}, {@code "Español"}, {@code "Deutsch"}, {@code "Français"})
 * @param flagEmoji    regional indicator or icon emoji (e.g., {@code "🇺🇸"}, {@code "🇬🇧"}, {@code "🇪🇸"}, {@code "🇩🇪"}, {@code "🇫🇷"})
 * @param translations immutable map of message keys to UTF-8 localized templates
 */
public record LanguagePackDescriptor(
        String localeCode,
        String displayName,
        String nativeName,
        String flagEmoji,
        Map<String, String> translations
) {

    /**
     * Validates and normalizes the language pack descriptor fields.
     */
    public LanguagePackDescriptor {
        Objects.requireNonNull(localeCode, "localeCode must not be null");
        localeCode = localeCode.trim();
        if (localeCode.isEmpty()) {
            throw new IllegalArgumentException("localeCode must not be blank");
        }
        displayName = (displayName == null || displayName.isBlank()) ? localeCode : displayName.trim();
        nativeName = (nativeName == null || nativeName.isBlank()) ? displayName : nativeName.trim();
        flagEmoji = (flagEmoji == null || flagEmoji.isBlank()) ? "🌐" : flagEmoji.trim();
        if (translations == null || translations.isEmpty()) {
            translations = Collections.emptyMap();
        } else {
            translations = Collections.unmodifiableMap(new LinkedHashMap<>(translations));
        }
    }

    /**
     * Formats a user-friendly selector label combining the flag emoji, native name, display name, and locale tag.
     *
     * @return formatted label for UI language selectors
     */
    public String formatSelectorLabel() {
        if (nativeName.equalsIgnoreCase(displayName)) {
            return flagEmoji + " " + nativeName + " [" + localeCode + "]";
        }
        return flagEmoji + " " + nativeName + " — " + displayName + " [" + localeCode + "]";
    }
}
