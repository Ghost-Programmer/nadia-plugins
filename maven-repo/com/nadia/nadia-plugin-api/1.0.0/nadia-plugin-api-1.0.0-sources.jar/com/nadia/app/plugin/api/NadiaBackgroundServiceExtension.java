package com.nadia.app.plugin.api;

import org.pf4j.ExtensionPoint;

import java.util.Collections;
import java.util.List;

/**
 * PF4J {@link ExtensionPoint} allowing plugins to register background services, subscribe to Nadia's
 * outbound event bus, and schedule periodic background tasks.
 */
public interface NadiaBackgroundServiceExtension extends ExtensionPoint {

    /**
     * Returns a human-readable name for this background service extension.
     *
     * @return service name
     */
    default String getServiceName() {
        return getClass().getSimpleName();
    }

    /**
     * Invoked when the owning plugin is started.
     *
     * @param context the host {@link NadiaPluginContext}
     */
    default void onPluginStarted(NadiaPluginContext context) {
        // Default no-op
    }

    /**
     * Invoked when the owning plugin is stopped, disabled, or unloaded.
     *
     * @param context the host {@link NadiaPluginContext}
     */
    default void onPluginStopped(NadiaPluginContext context) {
        // Default no-op
    }

    /**
     * Invoked whenever an outbound system event is published in Nadia (e.g., printer alerts,
     * network topology changes, camera events, or custom plugin events).
     *
     * @param source    event source category
     * @param eventType event type identifier
     * @param target    event target identifier
     * @param payload   event payload or details
     * @param context   the host {@link NadiaPluginContext}
     */
    default void onSystemEvent(String source,
                               String eventType,
                               String target,
                               String payload,
                               NadiaPluginContext context) {
        // Default no-op
    }

    /**
     * Returns periodic background tasks that Nadia should schedule while this plugin is active.
     *
     * @param context the host {@link NadiaPluginContext}
     * @return list of {@link PluginScheduledTask} descriptors (empty by default)
     */
    default List<PluginScheduledTask> getScheduledTasks(NadiaPluginContext context) {
        return Collections.emptyList();
    }
}

