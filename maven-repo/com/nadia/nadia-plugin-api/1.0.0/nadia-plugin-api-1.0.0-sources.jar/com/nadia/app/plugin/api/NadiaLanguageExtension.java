package com.nadia.app.plugin.api;

import org.pf4j.ExtensionPoint;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/**
 * PF4J {@link ExtensionPoint} allowing plugins to contribute full or partial UI &amp; AI localization
 * language packs to Nadia.
 *
 * <p>Implementations are pure Java (requiring zero JavaFX dependencies) so language packs load cleanly
 * in both desktop GUI and headless test/CLI environments. When a language pack plugin is installed and
 * enabled in {@code ~/.nadia/plugins/}, Nadia automatically registers its {@link LanguagePackDescriptor}
 * into {@code NadiaI18nService} and lists it in <b>Settings -&gt; System Settings -&gt; Language &amp; Localization</b>.</p>
 */
public interface NadiaLanguageExtension extends ExtensionPoint {

    /**
     * Returns the {@link LanguagePackDescriptor} contributed by this extension.
     *
     * @return non-null language pack descriptor containing locale metadata and UTF-8 message translations
     */
    LanguagePackDescriptor getLanguagePack();

    /**
     * Utility helper that loads a UTF-8 encoded {@code .properties} resource stream from the given
     * {@link ClassLoader} into an immutable ordered {@link Map}.
     *
     * @param classLoader  the plugin or host class loader owning the resource
     * @param resourcePath classpath resource path (with or without leading {@code '/'}, e.g., {@code "i18n/messages_es.properties"})
     * @return unmodifiable map of property keys to UTF-8 string values
     * @throws IllegalArgumentException if the resource cannot be found on the given class loader
     * @throws UncheckedIOException     if an I/O error occurs while reading the resource
     */
    static Map<String, String> loadUtf8Properties(ClassLoader classLoader, String resourcePath) {
        if (classLoader == null) {
            throw new IllegalArgumentException("classLoader must not be null");
        }
        if (resourcePath == null || resourcePath.isBlank()) {
            throw new IllegalArgumentException("resourcePath must not be blank");
        }
        String normalized = resourcePath.startsWith("/") ? resourcePath.substring(1) : resourcePath;
        try (InputStream in = classLoader.getResourceAsStream(normalized)) {
            if (in == null) {
                throw new IllegalArgumentException("Language properties resource not found: " + normalized);
            }
            Properties props = new Properties();
            try (InputStreamReader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                props.load(reader);
            }
            Map<String, String> map = new LinkedHashMap<>(props.size());
            for (String name : props.stringPropertyNames()) {
                map.put(name, props.getProperty(name));
            }
            return Collections.unmodifiableMap(map);
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to load UTF-8 language properties from " + normalized, e);
        }
    }
}
