package com.nadia.app.plugin.api;

import org.pf4j.Plugin;
import org.pf4j.PluginWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Base class for PF4J plugins targeting the Nadia cognitive agent platform.
 *
 * <p>Subclasses receive access to {@link NadiaPluginContext} and lifecycle callbacks
 * ({@link #onStart(NadiaPluginContext)} and {@link #onStop(NadiaPluginContext)}). Standard
 * PF4J {@link Plugin} subclasses that do not extend {@code NadiaPlugin} are also fully supported.</p>
 */
public abstract class NadiaPlugin extends Plugin {

    protected final Logger logger = LoggerFactory.getLogger(getClass());
    private volatile NadiaPluginContext pluginContext;

    /**
     * Constructs a {@code NadiaPlugin} bound to the given PF4J {@link PluginWrapper}.
     *
     * @param wrapper the PF4J plugin wrapper
     */
    protected NadiaPlugin(PluginWrapper wrapper) {
        super(wrapper);
    }

    /**
     * Injects the host {@link NadiaPluginContext} prior to plugin startup.
     *
     * @param pluginContext the host plugin context facade
     */
    public final void setPluginContext(NadiaPluginContext pluginContext) {
        this.pluginContext = pluginContext;
    }

    /**
     * Returns the host {@link NadiaPluginContext} facade.
     *
     * @return the host plugin context
     */
    public final NadiaPluginContext getPluginContext() {
        return pluginContext;
    }

    @Override
    public void start() {
        logger.info("[PF4J] Starting NadiaPlugin '{}'", wrapper != null ? wrapper.getPluginId() : getClass().getSimpleName());
        if (pluginContext != null) {
            onStart(pluginContext);
        }
    }

    @Override
    public void stop() {
        logger.info("[PF4J] Stopping NadiaPlugin '{}'", wrapper != null ? wrapper.getPluginId() : getClass().getSimpleName());
        if (pluginContext != null) {
            onStop(pluginContext);
        }
    }

    /**
     * Hook invoked when the plugin is started by Nadia.
     *
     * @param context the host {@link NadiaPluginContext}
     */
    protected void onStart(NadiaPluginContext context) {
        // Default no-op
    }

    /**
     * Hook invoked when the plugin is stopped or unloaded by Nadia.
     *
     * @param context the host {@link NadiaPluginContext}
     */
    protected void onStop(NadiaPluginContext context) {
        // Default no-op
    }
}

