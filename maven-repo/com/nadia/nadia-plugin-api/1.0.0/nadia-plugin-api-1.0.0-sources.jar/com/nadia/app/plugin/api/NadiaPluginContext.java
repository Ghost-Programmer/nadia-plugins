package com.nadia.app.plugin.api;

import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

/**
 * Host facade providing PF4J plugins and {@code @Extension} implementations with safe, structured
 * access to Nadia's core services, configuration properties ({@code nadia.prop.*}), episodic memory,
 * intelligence briefs, outbound event bus, and underlying Spring application context.
 *
 * <p>Plugin extensions can either access this facade via {@link NadiaPlugin#getPluginContext()}
 * or have it (or any Nadia Spring bean) injected directly via {@code @Autowired} when loaded by
 * Nadia's PF4J-Spring bridge.</p>
 */
public interface NadiaPluginContext {

    /**
     * Retrieves a configuration property from {@code ~/.nadia/nadia.properties}.
     * Automatically normalizes keys without the {@code nadia.prop.} prefix.
     *
     * @param key          the property key (e.g., {@code "nadia.prop.myplugin.apiKey"} or {@code "myplugin.apiKey"})
     * @param defaultValue fallback value if unset
     * @return the resolved property value or {@code defaultValue}
     */
    String getProperty(String key, String defaultValue);

    /**
     * Persists a configuration property into {@code ~/.nadia/nadia.properties}.
     *
     * @param key   the property key
     * @param value the value to store
     */
    void setProperty(String key, String value);

    /**
     * Registers required or optional {@code nadia.prop.*} property keys so they appear in Nadia's
     * Settings -> Properties UI tab.
     *
     * @param keys   list of property keys
     * @param source descriptive source label (e.g., {@code "Plugin: weather-radar"})
     */
    void registerProperties(List<String> keys, String source);

    /**
     * Publishes an event onto Nadia's autonomous staff event bus (`StaffEventService`).
     *
     * @param source    event category/source (e.g., {@code "plugin"}, {@code "printer"}, {@code "network"})
     * @param eventType specific event type identifier
     * @param target    target entity or device identifier
     * @param details   event payload or summary text
     */
    void publishEvent(String source, String eventType, String target, String details);

    /**
     * Records an entry in Nadia's persistent daily executive brief (`BriefService`).
     *
     * @param category  brief category (e.g., {@code "plugin"}, {@code "security"}, {@code "ops"})
     * @param staffName authoring staff or plugin name
     * @param code      unique deduplication code
     * @param content   markdown brief content
     */
    void storeBrief(String category, String staffName, String code, String content);

    /**
     * Saves a semantic fact into Nadia's episodic vector memory store.
     *
     * @param content  factual statement to persist
     * @param category memory category
     * @param tags     comma-separated tags
     */
    void saveMemory(String content, String category, String tags);

    /**
     * Performs a semantic similarity search over Nadia's episodic vector memory store.
     *
     * @param query natural-language search query
     * @param topK  maximum number of results to return
     * @return list of matching memory fact strings
     */
    List<String> searchMemory(String query, int topK);

    /**
     * Resolves the dedicated persistent data directory for a specific plugin
     * ({@code ~/.nadia/plugins/data/<pluginId>}). Automatically creates the directory if missing.
     *
     * @param pluginId the PF4J plugin ID
     * @return path to the plugin's data directory
     */
    Path getPluginDataDir(String pluginId);

    /**
     * Returns the root Nadia home directory ({@code ~/.nadia}).
     *
     * @return path to {@code ~/.nadia}
     */
    Path getNadiaHomeDir();

    /**
     * Looks up a Spring-managed bean from Nadia's host {@code ApplicationContext}.
     *
     * @param beanClass the target bean class
     * @param <T>       bean type
     * @return optional containing the host Spring bean if available
     */
    <T> Optional<T> getSpringBean(Class<T> beanClass);

    /**
     * Opens or brings to focus a BentoFX dockable window registered on Nadia's desktop workspace
     * (either a built-in host dockable or a plugin-contributed dockable).
     *
     * @param dockableId unique dockable identifier (e.g., {@code "map"})
     */
    default void openDockable(String dockableId) {
        // Default no-op in headless or standalone environments
    }
}

