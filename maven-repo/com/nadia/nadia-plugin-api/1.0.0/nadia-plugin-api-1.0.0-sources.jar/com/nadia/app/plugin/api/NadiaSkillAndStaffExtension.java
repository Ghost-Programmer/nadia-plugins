package com.nadia.app.plugin.api;

import org.pf4j.ExtensionPoint;

import java.util.Collections;
import java.util.List;

/**
 * PF4J {@link ExtensionPoint} allowing plugins to programmatically contribute procedural skills
 * ({@code SKILL.md}) and specialist staff personas ({@code STAFF.md}) to Nadia.
 *
 * <p>Note: In addition to implementing this interface, plugins may also bundle {@code skills/<category>/<slug>/SKILL.md}
 * and {@code staff/<StaffName>/STAFF.md} files directly inside their JAR/ZIP resources, which Nadia
 * automatically extracts and registers when the plugin is loaded.</p>
 */
public interface NadiaSkillAndStaffExtension extends ExtensionPoint {

    /**
     * Returns procedural skills contributed by this plugin extension.
     *
     * @return list of {@link BundledSkillDescriptor} items
     */
    default List<BundledSkillDescriptor> getBundledSkills() {
        return Collections.emptyList();
    }

    /**
     * Returns specialist staff personas contributed by this plugin extension.
     *
     * @return list of {@link BundledStaffDescriptor} items
     */
    default List<BundledStaffDescriptor> getBundledStaff() {
        return Collections.emptyList();
    }
}

