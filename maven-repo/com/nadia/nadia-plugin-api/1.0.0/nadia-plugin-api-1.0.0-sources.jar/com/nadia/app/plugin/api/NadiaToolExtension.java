package com.nadia.app.plugin.api;

import com.nadia.app.annotation.NadiaTool;
import com.nadia.app.orchestrator.AgentTool;
import org.pf4j.ExtensionPoint;

import java.util.Collections;
import java.util.List;

/**
 * PF4J {@link ExtensionPoint} allowing plugins to contribute executable agent tools to Nadia,
 * Spring AI, and Antigravity.
 *
 * <p>Any {@code @Extension} class implementing {@code NadiaToolExtension} can expose tools in two ways:</p>
 * <ol>
 *   <li><strong>Declarative {@link NadiaTool} / Spring AI {@code @Tool} methods</strong>: Any public method
 *       annotated with {@link NadiaTool} or {@code @Tool} on the extension class is automatically scanned,
 *       converted into an {@link AgentTool} with JSON Schema parameters, and registered in Nadia's
 *       {@code ToolRegistry} (along with any required {@code nadia.prop.*} properties).</li>
 *   <li><strong>Programmatic {@link AgentTool} instances</strong>: Override {@link #getDynamicTools()}
 *       to return dynamically constructed {@link AgentTool} callbacks.</li>
 * </ol>
 */
public interface NadiaToolExtension extends ExtensionPoint {

    /**
     * Returns any programmatic {@link AgentTool} instances contributed by this extension, in addition
     * to any methods annotated with {@link NadiaTool}.
     *
     * @return list of dynamic {@link AgentTool} instances (empty by default)
     */
    default List<AgentTool> getDynamicTools() {
        return Collections.emptyList();
    }
}

