package com.nadia.app.plugin.api;

import javafx.scene.Node;
import javafx.scene.control.Tab;
import org.pf4j.ExtensionPoint;

import java.util.Optional;

/**
 * PF4J {@link ExtensionPoint} allowing plugins to contribute JavaFX UI components to Nadia's desktop shell,
 * including BentoFX dockable workspace windows, custom Settings tabs, and Left Side Panel widgets.
 */
public interface NadiaUiExtension extends ExtensionPoint {

    /**
     * Contributes a BentoFX dockable window to Nadia's main {@code WorkspaceCanvas} and **Tools** menu.
     *
     * @param context the host {@link NadiaPluginContext}
     * @return optional {@link PluginDockableDescriptor}
     */
    default Optional<PluginDockableDescriptor> createDockableWindow(NadiaPluginContext context) {
        return Optional.empty();
    }

    /**
     * Contributes a custom configuration {@link Tab} to Nadia's {@code SettingsWindowView}.
     *
     * @param context the host {@link NadiaPluginContext}
     * @return optional JavaFX {@link Tab}
     */
    default Optional<Tab> createSettingsTab(NadiaPluginContext context) {
        return Optional.empty();
    }

    /**
     * Contributes a custom JavaFX {@link Node} widget or card to Nadia's Left Side Panel.
     *
     * @param context the host {@link NadiaPluginContext}
     * @return optional JavaFX {@link Node}
     */
    default Optional<Node> createSidePanelSection(NadiaPluginContext context) {
        return Optional.empty();
    }
}

