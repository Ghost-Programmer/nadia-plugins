package com.nadia.app.plugin.api;

/**
 * Immutable descriptor representing a single assistant or specialist turn returned during a
 * multi-agent chat invocation via {@link NadiaPluginContext}.
 *
 * @param staffName canonical name of the responding persona (for example, {@code "Nadia"} or {@code "Software Architect"})
 * @param text      Markdown response text produced by the persona
 */
public record PluginChatTurn(
        String staffName,
        String text
) {
}

