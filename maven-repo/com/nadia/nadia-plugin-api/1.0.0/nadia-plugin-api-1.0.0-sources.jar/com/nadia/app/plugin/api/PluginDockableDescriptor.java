package com.nadia.app.plugin.api;

import javafx.scene.Node;

import java.util.function.Supplier;

/**
 * Descriptor for a BentoFX dockable workspace window contributed by a PF4J {@link NadiaUiExtension}.
 *
 * @param id             unique dockable identifier (e.g., {@code "plugin-telemetry-view"})
 * @param title          window tab title (e.g., {@code "🛰 Telemetry Monitor"})
 * @param targetDockArea target BentoFX dock region (e.g., {@code "center-right"}, {@code "bottom-left"})
 * @param contentFactory factory creating the JavaFX {@link Node} on the JavaFX Application Thread
 */
public record PluginDockableDescriptor(
        String id,
        String title,
        String targetDockArea,
        Supplier<Node> contentFactory
) {
}

