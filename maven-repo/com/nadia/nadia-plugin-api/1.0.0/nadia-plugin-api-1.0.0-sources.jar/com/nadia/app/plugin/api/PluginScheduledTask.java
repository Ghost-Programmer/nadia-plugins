package com.nadia.app.plugin.api;

import java.time.Duration;

/**
 * Descriptor for a periodic background task registered by a PF4J {@link NadiaBackgroundServiceExtension}.
 *
 * @param id       unique task identifier (e.g., {@code "plugin-weather-sweep"})
 * @param name     human-readable task description
 * @param interval execution interval between runs
 * @param task     runnable callback invoked on a named virtual thread
 */
public record PluginScheduledTask(
        String id,
        String name,
        Duration interval,
        Runnable task
) {
}

