package com.nadia.app.plugin.api;

/**
 * Immutable descriptor representing an available specialist staff persona (or root {@code Nadia} persona)
 * exposed to PF4J plugins for mention autocomplete and conversational routing.
 *
 * @param name     display persona name (for example, {@code "Nadia"} or {@code "Software Architect"})
 * @param emoji    domain icon emoji representing the persona
 * @param subtitle concise role or domain summary
 */
public record PluginStaffDescriptor(
        String name,
        String emoji,
        String subtitle
) {
}

